import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-bar',
  templateUrl: './bar.component.html',
  styleUrls: ['./bar.component.css']
})
export class BarComponent implements OnInit {
  weatherData: any; // weatherdata to be stored from the assets/directory

  hum_10: string = "";
  hum_20: string = "";
  hum_30: string = "";
  hum_40: string = "";
  hum_50: string = "";
  hum_60: string = "";
  hum_70: string = "";
  hum_80: string = "";
  hum_90: string = "";
  hum_100: string = "";


  private jsonData: any = [];

  private svg: any;
  private margin = 50;
  private width = 750 - (this.margin * 2);
  private height = 400 - (this.margin * 2);


  constructor(private httpClient: HttpClient) { }

  private getJsonData(): Observable<any> {
    return this.httpClient.get("./assets/weather_data.json");
  }

  private countNum(): void {
    // divide humidity out of 100% by ten different range
    var hum_10 = 0;
    var hum_20 = 0;
    var hum_30 = 0;
    var hum_40 = 0;
    var hum_50 = 0;
    var hum_60 = 0;
    var hum_70 = 0;
    var hum_80 = 0;
    var hum_90 = 0;
    var hum_100 = 0;

    for (let i = 0; i < 400; i++) {
      if (this.weatherData[i].humidity < 10) {
        hum_10 += 1;
      } else if (this.weatherData[i].humidity < 20 && this.weatherData[i].humidity >= 10) {
        hum_20 += 1;
      } else if (this.weatherData[i].humidity < 30 && this.weatherData[i].humidity >= 20) {
        hum_30 += 1;
      } else if (this.weatherData[i].humidity < 40 && this.weatherData[i].humidity >= 30) {
        hum_40 += 1;
      } else if (this.weatherData[i].humidity < 50 && this.weatherData[i].humidity >= 40) {
        hum_50 += 1;
      } else if (this.weatherData[i].humidity < 60 && this.weatherData[i].humidity >= 50) {
        hum_60 += 1;
      } else if (this.weatherData[i].humidity < 70 && this.weatherData[i].humidity >= 60) {
        hum_70 += 1;
      } else if (this.weatherData[i].humidity < 80 && this.weatherData[i].humidity >= 70) {
        hum_80 += 1;
      } else if (this.weatherData[i].humidity < 90 && this.weatherData[i].humidity >= 80) {
        hum_90 += 1;
      } else if (this.weatherData[i].humidity < 100 && this.weatherData[i].humidity >= 90) {
        hum_100 += 1;
      }
    }
    this.hum_10 = hum_10.toString();
    this.hum_20 = hum_20.toString();
    this.hum_30 = hum_30.toString();
    this.hum_40 = hum_40.toString();
    this.hum_50 = hum_50.toString();
    this.hum_60 = hum_60.toString();
    this.hum_70 = hum_70.toString();
    this.hum_80 = hum_80.toString();
    this.hum_90 = hum_90.toString();
    this.hum_100 = hum_100.toString();

  }



  ngOnInit(): void {
    this.getJsonData().subscribe(data => {
      this.weatherData = data;
      this.countNum();
      this.jsonData = [
        { "Framework": "0 ~ 10", "Stars": this.hum_10 },
        { "Framework": "10 ~ 20", "Stars": this.hum_20 },
        { "Framework": "20 ~ 30", "Stars": this.hum_30 },
        { "Framework": "30 ~ 40", "Stars": this.hum_40 },
        { "Framework": "40 ~ 50", "Stars": this.hum_50 },
        { "Framework": "50 ~ 60", "Stars": this.hum_60 },
        { "Framework": "60 ~ 70", "Stars": this.hum_70 },
        { "Framework": "70 ~ 80", "Stars": this.hum_80 },
        { "Framework": "80 ~ 90", "Stars": this.hum_90 },
        { "Framework": "90 ~ 100", "Stars": this.hum_100 }
      ]
      this.createSvg();
      this.drawBars(this.jsonData);
    })
    // Comment out the line above and uncomment the line below when you're
    // ready to try fetching JSON from a REST API endpoint.
    // Comment out the private data [] above too.
    // d3.json('https://api.jsonbin.io/b/5eee6a5397cb753b4d149343').then((data: any) => this.drawBars(data));
  }



  private createSvg(): void {
    this.svg = d3.select("figure#bar")
      .append("svg")
      .attr("width", this.width + (this.margin * 2))
      .attr("height", this.height + (this.margin * 2))
      .append("g")
      .attr("transform", "translate(" + this.margin + "," + this.margin + ")");
  }

  private drawBars(data: any[]): void {
    // Create the X-axis band scale
    const x = d3.scaleBand()
      .range([0, this.width])
      .domain(data.map(d => d.Framework))
      .padding(0.2);

    // Draw the X-axis on the DOM
    this.svg.append("g")
      .attr("transform", "translate(0," + this.height + ")")
      .call(d3.axisBottom(x))
      .selectAll("text")
      .attr("transform", "translate(-10,0)rotate(-45)")
      .style("text-anchor", "end");

    // Create the Y-axis band scale
    const y = d3.scaleLinear()
      .domain([0, 100])
      .range([this.height, 0]);

    // Draw the Y-axis on the DOM
    this.svg.append("g")
      .call(d3.axisLeft(y));

    // Create and fill the bars
    this.svg.selectAll("bars")
      .data(data)
      .enter()
      .append("rect")
      .attr("x", (d: any) => x(d.Framework))
      .attr("y", (d: any) => y(d.Stars))
      .attr("width", x.bandwidth())
      .attr("height", (d: any) => this.height - y(d.Stars))
      .attr("fill", "#d04a35");
  }
}
